Bible SuperSearch Bible Export

CSV
Comma separated values.  UTF-8 encoding.


Index of Bibles Included: 

File                              Bible                                                                            Language
================================================================================================================================================================
* asv.csv ----------------------- American Standard Version (1901) ----------------------------------------------- English
* asvs.csv ---------------------- American Standard Version w Strong's ------------------------------------------- English
* bishops.csv ------------------- Bishops Bible (1568) ----------------------------------------------------------- English
* coverdale.csv ----------------- Coverdale Bible (1535) --------------------------------------------------------- English
* geneva.csv -------------------- Geneva Bible (1587) ------------------------------------------------------------ English
* kjv.csv ----------------------- Authorized King James Version (1611 / 1769) ------------------------------------ English
* kjv_strongs.csv --------------- KJV with Strongs (1611 / 1769) ------------------------------------------------- English
* net.csv ----------------------- NET Bible® (1996-2016) --------------------------------------------------------- English
* tyndale.csv ------------------- Tyndale Bible ------------------------------------------------------------------ English
* web.csv ----------------------- World English Bible (2006) ----------------------------------------------------- English


